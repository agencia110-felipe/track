import { createHash } from 'crypto';
import { randomUUID } from 'crypto';

export function sha256(value) {
  return createHash('sha256').update(value).digest('hex');
}

export function normalizePhone(phone, countryCode = '55') {
  const digits = (phone || '').replace(/\D/g, '').replace(/^0+/, '');
  if (!digits) return '';
  if (digits.length >= 11) return digits;
  return countryCode + digits;
}

export function cleanObj(obj) {
  return Object.fromEntries(
    Object.entries(obj).filter(([, v]) => v != null && v !== '' && v !== undefined)
  );
}

export { randomUUID };

export function detectBrowser(ua = '') {
  if (/Chrome/.test(ua) && !/Edg/.test(ua)) return 'Chrome';
  if (/Firefox/.test(ua)) return 'Firefox';
  if (/Safari/.test(ua) && !/Chrome/.test(ua)) return 'Safari';
  if (/Edg/.test(ua)) return 'Edge';
  return 'Other';
}

export function detectOS(ua = '') {
  if (/Android/.test(ua)) return 'Android';
  if (/iPhone|iPad/.test(ua)) return 'iOS';
  if (/Windows/.test(ua)) return 'Windows';
  if (/Mac/.test(ua)) return 'MacOS';
  if (/Linux/.test(ua)) return 'Linux';
  return 'Other';
}

export function isMobile(ua = '') {
  return /Android|iPhone|iPad|Mobile/.test(ua);
}
