import 'dotenv/config';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import pg from 'pg';

const { Pool } = pg;
const __dirname = dirname(fileURLToPath(import.meta.url));

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

try {
  const sql = readFileSync(join(__dirname, '../migrations/001_schema.sql'), 'utf8');
  await pool.query(sql);
  console.log('✓ Migrations aplicadas com sucesso.');
} catch (err) {
  console.error('✗ Erro ao aplicar migrations:', err.message);
  process.exit(1);
} finally {
  await pool.end();
}
