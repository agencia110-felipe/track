import pg from 'pg';
const { Pool } = pg;

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

pool.on('error', (err) => {
  console.error('[DB] Unexpected error on idle client', err.message);
});

// Helpers que imitam a API do D1 para facilitar migração
export const db = {
  async query(sql, params = []) {
    const client = await pool.connect();
    try {
      const res = await client.query(sql, params);
      return res.rows;
    } finally {
      client.release();
    }
  },

  // Retorna só a primeira linha (equivalente ao .first() do D1)
  async queryOne(sql, params = []) {
    const rows = await db.query(sql, params);
    return rows[0] || null;
  },

  // Executa sem retornar rows (INSERT/UPDATE/DELETE)
  async run(sql, params = []) {
    const client = await pool.connect();
    try {
      const res = await client.query(sql, params);
      return { rowCount: res.rowCount };
    } finally {
      client.release();
    }
  },
};

export default pool;
