import { db } from '../../db.js';
import { sha256, normalizePhone, cleanObj, randomUUID } from '../../utils.js';

export async function processWebhookPurchase(purchase) {
  const {
    clientId, platform, transactionId, status,
    value, currency = 'BRL', buyer = {}, trk, orderId, eventSourceUrl,
  } = purchase;

  const approvedStatuses = ['approved', 'paid', 'complete', 'completed', 'processing'];
  if (!approvedStatuses.includes((status || '').toLowerCase())) {
    console.log(`[webhook] skip status=${status} tx=${transactionId}`);
    return { skipped: true, reason: 'status_not_approved' };
  }

  // Deduplicação
  if (transactionId) {
    const exists = await db.queryOne(
      'SELECT id FROM purchase_log WHERE transaction_id = $1 AND client_id = $2',
      [transactionId, clientId]
    );
    if (exists) return { skipped: true, reason: 'duplicate' };
  }

  // Credenciais do cliente
  const platforms = await db.query(
    `SELECT platform, pixel_id, access_token, test_event_code,
            measurement_id, api_secret, conversion_id, conversion_label
     FROM client_platforms WHERE client_id = $1 AND enabled = TRUE`,
    [clientId]
  );
  const creds = {};
  platforms.forEach(p => { creds[p.platform] = p; });

  // Enriquece com sessão via TRK
  let sessionData = {};
  if (trk) {
    sessionData = await db.queryOne(
      'SELECT * FROM sessions WHERE session_id = $1 AND client_id = $2',
      [trk, clientId]
    ) || {};
  }

  // PII → hash
  const rawEmail = (buyer.email || '').toLowerCase().trim();
  const nameParts = (buyer.name || '').trim().split(/\s+/);
  const rawFirst  = (nameParts[0] || '').toLowerCase();
  const rawLast   = nameParts.slice(1).join(' ').toLowerCase();
  const rawPhone  = normalizePhone(buyer.phone || '');

  const hashedEm  = rawEmail ? sha256(rawEmail) : '';
  const hashedFn  = rawFirst ? sha256(rawFirst) : '';
  const hashedLn  = rawLast  ? sha256(rawLast)  : '';
  const hashedPh  = rawPhone ? sha256(rawPhone) : '';
  const externalId = sessionData.external_id || randomUUID();
  const hashedEid  = sha256(externalId);

  const eventId   = randomUUID();
  const eventTime = Math.floor(Date.now() / 1000);
  const fbp  = sessionData.fbp  || '';
  const fbc  = sessionData.fbc  || '';
  const gclid = sessionData.gclid || '';

  const userData = cleanObj({
    em:          hashedEm  ? [hashedEm]  : undefined,
    fn:          hashedFn  ? [hashedFn]  : undefined,
    ln:          hashedLn  ? [hashedLn]  : undefined,
    ph:          hashedPh  ? [hashedPh]  : undefined,
    external_id: [hashedEid],
    fbp:         fbp  || undefined,
    fbc:         fbc  || undefined,
  });

  const customData = cleanObj({
    value:    value || 0,
    currency,
    order_id: orderId || transactionId,
  });

  const results = {};

  // ── Meta CAPI ──────────────────────────────────────────────
  if (creds.meta?.pixel_id && creds.meta?.access_token) {
    const payload = {
      data: [{
        event_name: 'Purchase',
        event_time: eventTime,
        event_id: eventId,
        event_source_url: eventSourceUrl || sessionData.landing_url || '',
        action_source: 'website',
        user_data: userData,
        custom_data: customData,
      }],
    };
    if (creds.meta.test_event_code) payload.test_event_code = creds.meta.test_event_code;

    try {
      const res = await fetch(
        `https://graph.facebook.com/v20.0/${creds.meta.pixel_id}/events?access_token=${creds.meta.access_token}`,
        { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
      );
      const body = await res.json().catch(() => ({}));
      results.meta = { ok: res.ok, status: res.status, body };
    } catch (e) {
      results.meta = { ok: false, error: e.message };
    }
  }

  // ── GA4 MP ─────────────────────────────────────────────────
  if (creds.ga4?.measurement_id && creds.ga4?.api_secret) {
    const payload = {
      client_id: `${Date.now()}.${Math.floor(Math.random() * 1e9)}`,
      events: [{
        name: 'purchase',
        params: {
          transaction_id: transactionId || eventId,
          value: value || 0,
          currency,
          engagement_time_msec: 1,
        },
      }],
    };
    try {
      const res = await fetch(
        `https://www.google-analytics.com/mp/collect?measurement_id=${creds.ga4.measurement_id}&api_secret=${creds.ga4.api_secret}`,
        { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
      );
      results.ga4 = { ok: res.ok, status: res.status };
    } catch (e) {
      results.ga4 = { ok: false, error: e.message };
    }
  }

  // ── Persiste ───────────────────────────────────────────────
  try {
    await db.run(
      `INSERT INTO purchase_log (
         client_id, trk, event_id, event_time,
         raw_email, raw_name, raw_phone,
         hashed_em, hashed_fn, hashed_ln, hashed_ph, hashed_external_id,
         fbp, fbc, gclid, value, currency,
         transaction_id, order_id, platform,
         utm_source, utm_medium, utm_campaign, utm_content, utm_term,
         meta_status_code, meta_response_ok,
         ga4_status_code,  ga4_response_ok,
         event_source_url, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,
               $18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31)`,
      [
        clientId, trk || '', eventId, eventTime,
        rawEmail, buyer.name || '', rawPhone,
        hashedEm, hashedFn, hashedLn, hashedPh, hashedEid,
        fbp, fbc, gclid, value || 0, currency,
        transactionId || '', orderId || '', platform,
        sessionData.utm_source || '', sessionData.utm_medium || '',
        sessionData.utm_campaign || '', sessionData.utm_content || '',
        sessionData.utm_term || '',
        results.meta?.status || 0, results.meta?.ok || false,
        results.ga4?.status  || 0, results.ga4?.ok  || false,
        eventSourceUrl || '', Date.now(),
      ]
    );
  } catch (e) {
    console.error('[webhook core] purchase_log error:', e.message);
  }

  console.log(`[webhook] Purchase processada | cliente=${clientId} plataforma=${platform} valor=${value} meta=${results.meta?.ok} ga4=${results.ga4?.ok}`);
  return { ok: true, eventId, results };
}
