import { db } from '../../db.js';
import { processWebhookPurchase } from './_core.js';

export async function webhookRoutes(fastify) {

  // ── Helper: valida slug e retorna client_id ────────────────
  async function getClientBySlug(platform, slug) {
    return db.queryOne(
      'SELECT client_id FROM client_webhooks WHERE slug = $1 AND platform = $2 AND enabled = TRUE',
      [slug, platform]
    );
  }

  // ══════════════════════════════════════════════════════════
  // HOTMART
  // ══════════════════════════════════════════════════════════
  fastify.post('/webhook/hotmart/:slug', async (req, reply) => {
    const wh = await getClientBySlug('hotmart', req.params.slug);
    if (!wh) return reply.code(404).send('not found');

    const b = req.body || {};
    const data = b.data || b;
    const buyer = data.buyer || data.purchase?.buyer || {};
    const prod  = data.product || {};

    // Hotmart usa campo hottok para rastreio
    const trk = data.tracking?.source_sck
             || data.tracking?.external_code
             || b.hottok
             || '';

    const result = await processWebhookPurchase({
      clientId:       wh.client_id,
      platform:       'hotmart',
      transactionId:  String(data.purchase?.transaction || data.id || ''),
      status:         normalizeHotmart(data.purchase?.status || b.event || ''),
      value:          parseFloat(data.purchase?.price?.value || data.price || 0),
      currency:       data.purchase?.price?.currency_value || 'BRL',
      productName:    prod.name || '',
      buyer: {
        email: buyer.email || '',
        name:  buyer.name  || '',
        phone: buyer.phone || '',
      },
      trk,
      eventSourceUrl: data.purchase?.checkout_country?.code ? '' : '',
    });
    return reply.send(result);
  });

  // ══════════════════════════════════════════════════════════
  // KIWIFY
  // ══════════════════════════════════════════════════════════
  fastify.post('/webhook/kiwify/:slug', async (req, reply) => {
    const wh = await getClientBySlug('kiwify', req.params.slug);
    if (!wh) return reply.code(404).send('not found');

    const b = req.body || {};
    const customer = b.Customer || b.customer || {};
    const order    = b.Order    || b.order    || b;

    const result = await processWebhookPurchase({
      clientId:      wh.client_id,
      platform:      'kiwify',
      transactionId: String(order.order_id || order.id || b.order_id || ''),
      status:        normalizeKiwify(order.order_status || b.status || ''),
      value:         parseFloat(order.amount || order.price || b.amount || 0) / 100,
      currency:      'BRL',
      buyer: {
        email: customer.email || b.email || '',
        name:  customer.full_name || customer.name || '',
        phone: customer.CPF || customer.phone || '',
      },
      trk: order.tracking_id || b.tracking_id || b.src || '',
    });
    return reply.send(result);
  });

  // ══════════════════════════════════════════════════════════
  // EDUZZ / NUTROR
  // ══════════════════════════════════════════════════════════
  fastify.post('/webhook/eduzz/:slug', async (req, reply) => {
    const wh = await getClientBySlug('eduzz', req.params.slug);
    if (!wh) return reply.code(404).send('not found');

    const b = req.body || {};

    const result = await processWebhookPurchase({
      clientId:      wh.client_id,
      platform:      'eduzz',
      transactionId: String(b.trans_cod || b.sale_id || b.id || ''),
      status:        normalizeEduzz(b.trans_status || b.status || ''),
      value:         parseFloat(b.trans_value || b.amount || 0),
      currency:      'BRL',
      buyer: {
        email: b.client_email || b.email || '',
        name:  b.client_name  || b.name  || '',
        phone: b.client_phone || b.phone || '',
      },
      trk: b.tracking || b.src || '',
    });
    return reply.send(result);
  });

  // ══════════════════════════════════════════════════════════
  // WAKE COMMERCE
  // ══════════════════════════════════════════════════════════
  fastify.post('/webhook/wake/:slug', async (req, reply) => {
    const wh = await getClientBySlug('wake', req.params.slug);
    if (!wh) return reply.code(404).send('not found');

    const b = req.body || {};
    const order = b.order || b.data?.order || b;

    const result = await processWebhookPurchase({
      clientId:      wh.client_id,
      platform:      'wake',
      transactionId: String(order.id || order.orderId || order.order_id || ''),
      orderId:       String(order.id || order.orderId || ''),
      status:        normalizeWake(order.status || order.situation || b.event || ''),
      value:         parseFloat(order.value || order.total || order.totalPrice || 0),
      currency:      'BRL',
      buyer: {
        email: order.customer?.email || order.buyer?.email || '',
        name:  order.customer?.name  || order.buyer?.name  || '',
        phone: order.customer?.phone || order.buyer?.phone || '',
      },
      trk: order.partnerCode || order.xcod || order.sck || '',
    });
    return reply.send(result);
  });

  // ══════════════════════════════════════════════════════════
  // MAGENTO 2
  // ══════════════════════════════════════════════════════════
  fastify.post('/webhook/magento/:slug', async (req, reply) => {
    const wh = await getClientBySlug('magento', req.params.slug);
    if (!wh) return reply.code(404).send('not found');

    const b = req.body || {};
    const order  = b.order || b.data || b;
    const billing = order.billing_address || order.billingAddress || {};

    const result = await processWebhookPurchase({
      clientId:      wh.client_id,
      platform:      'magento',
      transactionId: String(order.increment_id || order.incrementId || order.id || ''),
      orderId:       String(order.increment_id || order.incrementId || ''),
      status:        normalizeMagento(order.status || b.event || ''),
      value:         parseFloat(order.grand_total || order.grandTotal || 0),
      currency:      order.base_currency_code || 'BRL',
      buyer: {
        email: order.customer_email || billing.email || '',
        name:  [order.customer_firstname || billing.firstname || '',
                order.customer_lastname  || billing.lastname  || ''].filter(Boolean).join(' '),
        phone: billing.telephone || billing.phone || '',
      },
      trk: order.tracking_code || order.konverta_trk || '',
    });
    return reply.send(result);
  });
}

// ── Normalizers de status ─────────────────────────────────────

function normalizeHotmart(s = '') {
  s = s.toLowerCase();
  if (s.includes('approved') || s.includes('complete') || s.includes('paid')) return 'approved';
  if (s.includes('refund') || s.includes('cancel') || s.includes('chargeback')) return 'refunded';
  return s;
}
function normalizeKiwify(s = '') {
  s = s.toLowerCase();
  if (['paid', 'approved', 'complete'].some(v => s.includes(v))) return 'approved';
  if (['refund', 'cancel', 'chargeback'].some(v => s.includes(v))) return 'refunded';
  return s;
}
function normalizeEduzz(s = '') {
  const map = { '3': 'approved', '5': 'approved', 'paid': 'approved', 'approved': 'approved', '4': 'refunded' };
  return map[s.toLowerCase()] || s.toLowerCase();
}
function normalizeWake(s = '') {
  s = s.toLowerCase();
  if (['approved', 'paid', 'payment_approved', 'order_paid', 'complete'].some(v => s.includes(v))) return 'approved';
  if (['refund', 'cancel', 'return'].some(v => s.includes(v))) return 'refunded';
  return s;
}
function normalizeMagento(s = '') {
  s = s.toLowerCase();
  if (['processing', 'complete', 'paid'].some(v => s.includes(v))) return 'approved';
  if (['closed', 'canceled', 'refunded'].some(v => s.includes(v))) return 'refunded';
  return s;
}
