import { db } from '../db.js';

export async function scriptRoute(fastify) {
  // GET /c/:clientId.js  — script dinâmico por cliente
  fastify.get('/c/:clientId', async (req, reply) => {
    const rawId   = req.params.clientId || '';
    const clientId = rawId.replace(/\.js$/, '');

    const client = await db.queryOne(
      'SELECT id, domain FROM clients WHERE id = $1 AND active = TRUE AND dns_verified = TRUE',
      [clientId]
    );
    if (!client) {
      return reply
        .code(404)
        .header('Content-Type', 'application/javascript')
        .send('// client not found');
    }

    const pages = await db.query(
      `SELECT id, name, page_type, event_name, url_pattern, url_match_type,
              field_map, fire_on, confirm_selector
       FROM conversion_pages WHERE client_id = $1 AND enabled = TRUE`,
      [clientId]
    );

    const conversionPages = pages.map(p => ({
      id: p.id,
      name: p.name,
      type: p.page_type,
      event: p.event_name,
      urlPattern: p.url_pattern,
      urlMatchType: p.url_match_type || 'contains',
      fields: p.field_map ? JSON.parse(p.field_map) : [],
      fireOn: p.fire_on || 'submit',
      confirmSelector: p.confirm_selector,
    }));

    const collectUrl = `https://${process.env.PLATFORM_DOMAIN}/collect`;
    const script = buildScript(clientId, collectUrl, conversionPages);

    return reply
      .header('Content-Type', 'application/javascript; charset=utf-8')
      .header('Cache-Control', 'public, max-age=300')
      .send(script);
  });
}

function buildScript(clientId, collectUrl, pages) {
  return `(function(){
  'use strict';
  var KV=window.__konverta=window.__konverta||{};
  if(KV._loaded)return; KV._loaded=true;
  var CLIENT_ID=${JSON.stringify(clientId)};
  var COLLECT_URL=${JSON.stringify(collectUrl)};
  var PAGES=${JSON.stringify(pages)};

  function getCookie(n){var m=document.cookie.match('(?:^|;)\\s*'+n+'=([^;]*)');return m?decodeURIComponent(m[1]):'';}
  function setCookie(n,v,d){var e=new Date(Date.now()+d*864e5).toUTCString();var dom=location.hostname.replace(/^www\./,'');document.cookie=n+'='+encodeURIComponent(v)+';expires='+e+';path=/;domain=.'+dom+';SameSite=Lax;Secure';}
  function uuid(){if(crypto.randomUUID)return crypto.randomUUID();return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,function(c){var r=Math.random()*16|0;return(c==='x'?r:(r&0x3|0x8)).toString(16)});}
  function getParam(n){var m=location.search.match('[?&]'+n+'=([^&]*)');return m?decodeURIComponent(m[1]):'';}
  function getRaw(n){var m=location.search.match('[?&]'+n+'=([^&]*)');return m?m[1]:'';}

  var sid=getCookie('_kv_sid'); if(!sid){sid=uuid();setCookie('_kv_sid',sid,400);}
  var eid=getCookie('_kv_eid'); if(!eid){eid=uuid();setCookie('_kv_eid',eid,400);}
  var fbclid=getRaw('fbclid'),gclid=getRaw('gclid'),msclkid=getRaw('msclkid');
  var utms={source:getParam('utm_source'),medium:getParam('utm_medium'),campaign:getParam('utm_campaign'),content:getParam('utm_content'),term:getParam('utm_term')};
  if(fbclid){setCookie('_fbc','fb.1.'+Date.now()+'.'+fbclid,90);}
  var fbp=getCookie('_fbp'); if(!fbp){fbp='fb.1.'+Date.now()+'.'+Math.floor(Math.random()*1e10);setCookie('_fbp',fbp,400);}
  var fbc=getCookie('_fbc');
  function getGaId(){var ga=getCookie('_ga');if(ga){var p=ga.split('.');if(p.length>=4)return p[2]+'.'+p[3];}return '';}

  function send(name,ud,cd,pid){
    var body=JSON.stringify({client_id:CLIENT_ID,event_name:name,event_id:uuid(),event_time:Math.floor(Date.now()/1000),event_source_url:location.href,page_id:pid||null,session_id:sid,user_data:Object.assign({fbp:fbp,fbc:fbc,ga_client_id:getGaId(),external_id:eid,client_user_agent:navigator.userAgent},ud||{}),custom_data:cd||{},utm:utms,fbclid:fbclid,gclid:gclid,msclkid:msclkid});
    if(navigator.sendBeacon){navigator.sendBeacon(COLLECT_URL,new Blob([body],{type:'application/json'}));}
    else{fetch(COLLECT_URL,{method:'POST',headers:{'Content-Type':'application/json'},body:body,keepalive:true}).catch(function(){});}
  }

  function extract(form,fields){var d={};fields.forEach(function(f){var el=form?form.querySelector(f.selector):document.querySelector(f.selector);if(el){var v=(el.value||el.textContent||'').trim();if(v)d[f.field]=v;}});return d;}
  function matchUrl(pat,type){if(!pat)return false;var p=location.pathname+location.search;if(type==='exact')return location.pathname===pat;if(type==='regex'){try{return new RegExp(pat).test(p);}catch(e){return false;}}return p.indexOf(pat)!==-1;}

  send('PageView',{},{});

  PAGES.forEach(function(page){
    if(page.urlPattern&&matchUrl(page.urlPattern,page.urlMatchType)){
      function fireUrl(){
        var ud={},cd={};
        if(page.fields&&page.fields.length){var ex=extract(null,page.fields);if(ex.email)ud.em=ex.email;if(ex.phone)ud.ph=ex.phone;if(ex.name)ud.fn=ex.name;if(ex.value)cd.value=parseFloat(ex.value)||0;if(ex.order_id)cd.order_id=ex.order_id;}
        send(page.event,ud,cd,page.id);
      }
      if(document.readyState!=='loading')setTimeout(fireUrl,500);
      else document.addEventListener('DOMContentLoaded',function(){setTimeout(fireUrl,500);});
      return;
    }
    if(page.fireOn==='submit'&&page.fields&&page.fields.length){
      function attach(){
        var first=page.fields[0]&&page.fields[0].selector;
        var el=first?document.querySelector(first):null;
        var form=el?el.closest('form'):document.querySelector('form');
        if(!form||form.__kvBound)return; form.__kvBound=true;
        form.addEventListener('submit',function(){
          var ex=extract(form,page.fields),ud={},cd={};
          if(ex.email)ud.em=ex.email;if(ex.phone)ud.ph=ex.phone;if(ex.name)ud.fn=ex.name;if(ex.last_name)ud.ln=ex.last_name;
          send(page.event,ud,cd,page.id);
        });
      }
      if(document.readyState!=='loading')attach();
      else document.addEventListener('DOMContentLoaded',attach);
      if(window.MutationObserver){var obs=new MutationObserver(attach);obs.observe(document.documentElement,{childList:true,subtree:true});}
    }
  });
})();`;
}
