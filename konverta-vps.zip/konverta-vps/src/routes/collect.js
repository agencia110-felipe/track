import { db } from '../db.js';
import { sha256, normalizePhone, cleanObj, randomUUID, detectBrowser, detectOS, isMobile } from '../utils.js';

export async function collectRoute(fastify) {
  fastify.post('/collect', async (req, reply) => {
    try {
      const body = req.body;
      const clientId = body?.client_id;
      if (!clientId) return reply.code(400).send({ error: 'invalid_request' });

      // Busca credenciais do cliente
      const platforms = await db.query(
        `SELECT platform, pixel_id, access_token, test_event_code,
                measurement_id, api_secret, conversion_id, conversion_label,
                tiktok_pixel_id, tiktok_access_token
         FROM client_platforms WHERE client_id = $1 AND enabled = TRUE`,
        [clientId]
      );
      const creds = {};
      platforms.forEach(p => { creds[p.platform] = p; });

      const ip  = req.headers['cf-connecting-ip'] ||
                  (req.headers['x-forwarded-for'] || '').split(',')[0].trim() ||
                  req.ip || '';
      const ua  = req.headers['user-agent'] || '';

      const eventName   = body.event_name || 'Lead';
      const eventId     = body.event_id || randomUUID();
      const eventTime   = body.event_time || Math.floor(Date.now() / 1000);
      const sourceUrl   = body.event_source_url || '';
      const sessionId   = body.session_id || '';
      const pageId      = body.page_id || null;
      const ud          = body.user_data || {};
      const cd          = body.custom_data || {};
      const utm         = body.utm || {};

      // Sessão
      let sessionData = {};
      if (sessionId) {
        sessionData = await db.queryOne(
          'SELECT * FROM sessions WHERE session_id = $1 AND client_id = $2',
          [sessionId, clientId]
        ) || {};
      }

      const fbp        = ud.fbp || sessionData.fbp || '';
      const fbc        = ud.fbc || sessionData.fbc || '';
      const gclid      = body.gclid || sessionData.gclid || '';
      const externalId = ud.external_id || sessionData.external_id || randomUUID();
      const now        = Date.now();

      // Upsert sessão
      if (sessionId) {
        await db.run(
          `INSERT INTO sessions (session_id, client_id, external_id, fbclid, gclid, msclkid,
             fbc, fbp, ip_address, user_agent, referrer, landing_url,
             utm_source, utm_medium, utm_campaign, utm_content, utm_term,
             created_at, updated_at)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
           ON CONFLICT (session_id, client_id) DO UPDATE SET
             fbc = COALESCE(NULLIF(EXCLUDED.fbc,''), sessions.fbc),
             fbp = COALESCE(NULLIF(EXCLUDED.fbp,''), sessions.fbp),
             gclid = COALESCE(NULLIF(EXCLUDED.gclid,''), sessions.gclid),
             updated_at = EXCLUDED.updated_at`,
          [sessionId, clientId, externalId,
           body.fbclid||'', gclid, body.msclkid||'',
           fbc, fbp, ip, ua, ud.referrer||'', sourceUrl,
           utm.source||'', utm.medium||'', utm.campaign||'',
           utm.content||'', utm.term||'', now, now]
        );
      }

      // PII → hash
      const rawEmail = (ud.em || '').toLowerCase().trim();
      const rawPhone = normalizePhone(ud.ph || '');
      const rawFirst = (ud.fn || '').toLowerCase().trim();
      const rawLast  = (ud.ln || '').toLowerCase().trim();

      const hashedEm  = rawEmail ? sha256(rawEmail) : '';
      const hashedPh  = rawPhone ? sha256(rawPhone) : '';
      const hashedFn  = rawFirst ? sha256(rawFirst) : '';
      const hashedLn  = rawLast  ? sha256(rawLast)  : '';
      const hashedEid = externalId ? sha256(externalId) : '';

      const userData = cleanObj({
        em: hashedEm  ? [hashedEm]  : undefined,
        ph: hashedPh  ? [hashedPh]  : undefined,
        fn: hashedFn  ? [hashedFn]  : undefined,
        ln: hashedLn  ? [hashedLn]  : undefined,
        external_id: [hashedEid],
        fbp: fbp || undefined,
        fbc: fbc || undefined,
        client_ip_address: ip,
        client_user_agent: ua,
      });

      const results = {};

      // ── Meta CAPI ────────────────────────────────────────────
      if (creds.meta?.pixel_id && creds.meta?.access_token) {
        const payload = {
          data: [{
            event_name: eventName,
            event_time: eventTime,
            event_id: eventId,
            event_source_url: sourceUrl,
            action_source: 'website',
            user_data: userData,
            custom_data: cleanObj(cd),
          }],
        };
        if (creds.meta.test_event_code) payload.test_event_code = creds.meta.test_event_code;

        try {
          const res = await fetch(
            `https://graph.facebook.com/v20.0/${creds.meta.pixel_id}/events?access_token=${creds.meta.access_token}`,
            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
          );
          results.meta = { ok: res.ok, status: res.status };
        } catch (e) { results.meta = { ok: false }; }
      }

      // ── GA4 MP ───────────────────────────────────────────────
      if (creds.ga4?.measurement_id && creds.ga4?.api_secret) {
        const gaClientId = ud.ga_client_id || `${Date.now()}.${Math.floor(Math.random() * 1e9)}`;
        const ga4EventMap = { Lead: 'generate_lead', Purchase: 'purchase', CompleteRegistration: 'sign_up', AddToCart: 'add_to_cart', ViewContent: 'view_item' };
        const payload = {
          client_id: gaClientId,
          events: [{ name: ga4EventMap[eventName] || eventName.toLowerCase(), params: { ...cd, engagement_time_msec: 1 } }],
        };
        try {
          const res = await fetch(
            `https://www.google-analytics.com/mp/collect?measurement_id=${creds.ga4.measurement_id}&api_secret=${creds.ga4.api_secret}`,
            { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }
          );
          results.ga4 = { ok: res.ok, status: res.status };
        } catch (e) { results.ga4 = { ok: false }; }
      }

      // ── Persiste no DB (sem PageViews para não inflar) ───────
      if (eventName !== 'PageView') {
        await db.run(
          `INSERT INTO event_log (
             client_id, session_id, event_name, event_id, page_id, timestamp,
             browser, os, is_mobile, pixel_was_blocked, fbp_source,
             sent_to_meta, meta_response_ok, sent_to_ga4, ga4_response_ok,
             has_email, has_phone, has_name)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)`,
          [
            clientId, sessionId, eventName, eventId, pageId, eventTime,
            detectBrowser(ua), detectOS(ua), isMobile(ua),
            (!ud.fbp && !ud.fbc),
            ud.fbp ? 'pixel_js' : (fbp ? 'server' : 'none'),
            !!creds.meta, results.meta?.ok || false,
            !!creds.ga4,  results.ga4?.ok  || false,
            !!rawEmail, !!rawPhone, !!rawFirst,
          ]
        );
      }

      return reply.send({ ok: true, event_id: eventId });
    } catch (e) {
      fastify.log.error(e);
      return reply.code(500).send({ error: 'internal_error' });
    }
  });
}
