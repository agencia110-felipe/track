-- Konverta — Schema PostgreSQL
-- Execute: psql -U konverta -d konverta -f migrations/001_schema.sql

-- ── CLIENTES ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS clients (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    domain      TEXT NOT NULL UNIQUE,
    dns_token   TEXT NOT NULL UNIQUE,
    dns_verified BOOLEAN DEFAULT FALSE,
    active      BOOLEAN DEFAULT TRUE,
    created_at  BIGINT NOT NULL,
    updated_at  BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_clients_domain ON clients(domain);

-- ── PLATAFORMAS POR CLIENTE ──────────────────────────────────
CREATE TABLE IF NOT EXISTS client_platforms (
    id               SERIAL PRIMARY KEY,
    client_id        TEXT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    platform         TEXT NOT NULL,
    pixel_id         TEXT,
    access_token     TEXT,
    test_event_code  TEXT,
    measurement_id   TEXT,
    api_secret       TEXT,
    conversion_id    TEXT,
    conversion_label TEXT,
    tiktok_pixel_id  TEXT,
    tiktok_access_token TEXT,
    enabled          BOOLEAN DEFAULT TRUE,
    created_at       BIGINT NOT NULL,
    UNIQUE(client_id, platform)
);
CREATE INDEX IF NOT EXISTS idx_platforms_client ON client_platforms(client_id);

-- ── PÁGINAS DE CONVERSÃO ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS conversion_pages (
    id               SERIAL PRIMARY KEY,
    client_id        TEXT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    name             TEXT NOT NULL,
    page_type        TEXT NOT NULL,
    event_name       TEXT NOT NULL DEFAULT 'Lead',
    url_pattern      TEXT,
    url_match_type   TEXT DEFAULT 'contains',
    field_map        TEXT,
    source_html      TEXT,
    fire_on          TEXT DEFAULT 'submit',
    confirm_selector TEXT,
    enabled          BOOLEAN DEFAULT TRUE,
    created_at       BIGINT NOT NULL,
    updated_at       BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_pages_client ON conversion_pages(client_id);

-- ── WEBHOOKS DE PLATAFORMAS DE VENDA ────────────────────────
CREATE TABLE IF NOT EXISTS client_webhooks (
    id        SERIAL PRIMARY KEY,
    client_id TEXT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    platform  TEXT NOT NULL,
    slug      TEXT NOT NULL UNIQUE,
    enabled   BOOLEAN DEFAULT TRUE,
    created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_webhooks_client ON client_webhooks(client_id);
CREATE INDEX IF NOT EXISTS idx_webhooks_slug   ON client_webhooks(slug);

-- ── SESSÕES ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sessions (
    session_id   TEXT NOT NULL,
    client_id    TEXT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    external_id  TEXT NOT NULL,
    fbclid       TEXT,
    gclid        TEXT,
    msclkid      TEXT,
    fbc          TEXT,
    fbp          TEXT,
    ip_address   TEXT,
    user_agent   TEXT,
    referrer     TEXT,
    landing_url  TEXT,
    utm_source   TEXT,
    utm_medium   TEXT,
    utm_campaign TEXT,
    utm_content  TEXT,
    utm_term     TEXT,
    created_at   BIGINT NOT NULL,
    updated_at   BIGINT NOT NULL,
    PRIMARY KEY (session_id, client_id)
);
CREATE INDEX IF NOT EXISTS idx_sessions_client ON sessions(client_id, created_at);

-- ── LOG DE EVENTOS ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS event_log (
    id               SERIAL PRIMARY KEY,
    client_id        TEXT NOT NULL,
    session_id       TEXT,
    event_name       TEXT NOT NULL,
    event_id         TEXT NOT NULL,
    page_id          INTEGER,
    timestamp        BIGINT NOT NULL,
    browser          TEXT,
    os               TEXT,
    is_mobile        BOOLEAN DEFAULT FALSE,
    pixel_was_blocked BOOLEAN DEFAULT FALSE,
    fbp_source       TEXT,
    is_bot           BOOLEAN DEFAULT FALSE,
    sent_to_meta     BOOLEAN DEFAULT FALSE,
    meta_response_ok BOOLEAN DEFAULT FALSE,
    sent_to_ga4      BOOLEAN DEFAULT FALSE,
    ga4_response_ok  BOOLEAN DEFAULT FALSE,
    has_email        BOOLEAN DEFAULT FALSE,
    has_phone        BOOLEAN DEFAULT FALSE,
    has_name         BOOLEAN DEFAULT FALSE
);
CREATE INDEX IF NOT EXISTS idx_event_client    ON event_log(client_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_event_name      ON event_log(event_name);

-- ── LOG DE COMPRAS ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS purchase_log (
    id                SERIAL PRIMARY KEY,
    client_id         TEXT NOT NULL,
    trk               TEXT,
    event_id          TEXT NOT NULL,
    event_time        BIGINT NOT NULL,
    raw_email         TEXT,
    raw_name          TEXT,
    raw_phone         TEXT,
    hashed_em         TEXT,
    hashed_fn         TEXT,
    hashed_ln         TEXT,
    hashed_ph         TEXT,
    hashed_external_id TEXT,
    client_ip_address TEXT,
    client_user_agent TEXT,
    fbp               TEXT,
    fbc               TEXT,
    gclid             TEXT,
    value             NUMERIC(12,2),
    currency          TEXT DEFAULT 'BRL',
    transaction_id    TEXT,
    order_id          TEXT,
    platform          TEXT,
    utm_source        TEXT,
    utm_medium        TEXT,
    utm_campaign      TEXT,
    utm_content       TEXT,
    utm_term          TEXT,
    meta_status_code  INTEGER,
    meta_response_ok  BOOLEAN DEFAULT FALSE,
    ga4_status_code   INTEGER,
    ga4_response_ok   BOOLEAN DEFAULT FALSE,
    gads_response_ok  BOOLEAN DEFAULT FALSE,
    event_source_url  TEXT,
    created_at        BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_purchase_client ON purchase_log(client_id, event_time);
CREATE INDEX IF NOT EXISTS idx_purchase_trk    ON purchase_log(trk);
CREATE INDEX IF NOT EXISTS idx_purchase_txid   ON purchase_log(transaction_id);
