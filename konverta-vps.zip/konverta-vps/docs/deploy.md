# Deploy do Konverta na VPS Kinghost
# Subdomínio: track.agencia110.com.br

> ⚠️ Este guia **não toca** em nenhum site ou aplicação existente na VPS.
> Tudo fica isolado: porta 3001, novo server block Nginx, banco de dados separado.

---

## PASSO 0 — Preparar o DNS (Painel Kinghost)

Antes de qualquer coisa, aponte o subdomínio para o IP da sua VPS.

1. Acesse o painel Kinghost → Gerenciar → DNS
2. Adicione um registro **A**:
   - Host: `track`
   - Valor: IP da sua VPS (ex: `179.x.x.x`)
   - TTL: 3600
3. Salve e aguarde até 30 minutos para propagar

---

## PASSO 1 — Conectar na VPS

```bash
ssh usuario@SEU_IP_VPS
```

---

## PASSO 2 — Fazer upload dos arquivos

No seu computador local, copie a pasta `konverta` para a VPS:

```bash
# Execute no seu computador (não na VPS)
scp -r ./konverta usuario@SEU_IP_VPS:/var/www/konverta
```

Ou se preferir via Git (recomendado):

```bash
# Na VPS:
cd /var/www
git clone https://github.com/SEU_USUARIO/konverta.git
cd konverta
```

---

## PASSO 3 — Instalar dependências Node.js

```bash
cd /var/www/konverta
node -v   # Confirme que é Node 18+ (se não for, instale abaixo)
npm install
```

Se precisar atualizar o Node.js:
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
```

---

## PASSO 4 — Configurar o PostgreSQL

```bash
# Abre o psql como superusuário
sudo -u postgres psql

# Dentro do psql — crie banco e usuário isolados para o Konverta
CREATE USER konverta WITH PASSWORD 'ESCOLHA_UMA_SENHA_FORTE_AQUI';
CREATE DATABASE konverta OWNER konverta;
GRANT ALL PRIVILEGES ON DATABASE konverta TO konverta;
\q
```

Teste a conexão:
```bash
psql -U konverta -d konverta -h localhost -c "SELECT 1;"
# Deve retornar: (1 row)
```

---

## PASSO 5 — Criar o arquivo .env

```bash
cd /var/www/konverta
cp .env.example .env
nano .env
```

Edite com seus dados reais:

```env
DATABASE_URL=postgresql://konverta:SUA_SENHA_FORTE@localhost:5432/konverta
ADMIN_KEY=crie-uma-chave-segura-aqui-ex-4f7k2m9p1x
DASH_KEY=outra-chave-diferente-ex-8r3t6n0q5w
PLATFORM_DOMAIN=track.agencia110.com.br
DEFAULT_COUNTRY_CODE=55
PORT=3001
NODE_ENV=production
```

> ⚠️ Salve as chaves em local seguro — sem elas você não acessa o painel.

---

## PASSO 6 — Executar as migrations

```bash
cd /var/www/konverta
npm run migrate
```

Deve mostrar: `✓ Migrations aplicadas com sucesso.`

---

## PASSO 7 — Configurar logs e PM2

```bash
# Cria pasta de logs
sudo mkdir -p /var/log/konverta
sudo chown $USER:$USER /var/log/konverta

# Inicia com PM2
pm2 start ecosystem.config.cjs --env production

# Verifica se está rodando
pm2 status

# Veja os logs em tempo real
pm2 logs konverta
```

Deve aparecer:
```
🚀 Konverta rodando na porta 3001
```

Salva o processo para reiniciar automaticamente no boot:
```bash
pm2 save
pm2 startup   # Copie e execute o comando que aparecer na tela
```

Teste rápido que está funcionando:
```bash
curl http://127.0.0.1:3001/health
# Deve retornar: {"ok":true,"ts":...}
```

---

## PASSO 8 — Configurar o Nginx (SEM MEXER nos sites existentes)

```bash
# Copia APENAS o novo server block — não sobrescreve nada
sudo cp /var/www/konverta/nginx.conf /etc/nginx/sites-available/konverta

# Ativa o site
sudo ln -s /etc/nginx/sites-available/konverta /etc/nginx/sites-enabled/konverta

# Testa se a sintaxe está correta (antes de aplicar!)
sudo nginx -t
```

Se aparecer `syntax is ok` e `test is successful`:

```bash
sudo systemctl reload nginx
```

> 🟢 Seus outros sites continuam funcionando normalmente.

---

## PASSO 9 — Instalar SSL com Certbot

```bash
# Instala Certbot (se ainda não tiver)
sudo apt install -y certbot python3-certbot-nginx

# Gera certificado APENAS para o subdomínio track
# Não afeta certificados de outros domínios
sudo certbot --nginx -d track.agencia110.com.br
```

O Certbot vai perguntar seu email e aceitar os termos — preencha.
Ele edita automaticamente o `/etc/nginx/sites-available/konverta` com os caminhos do certificado.

Teste a renovação automática:
```bash
sudo certbot renew --dry-run
```

---

## PASSO 10 — Verificar tudo funcionando

```bash
# Health check via HTTPS
curl https://track.agencia110.com.br/health
# Deve retornar: {"ok":true,"ts":...}

# Acessa o painel admin
# No navegador: https://track.agencia110.com.br/admin?key=SUA_ADMIN_KEY
```

---

## Comandos úteis no dia a dia

```bash
# Ver status da aplicação
pm2 status

# Ver logs ao vivo
pm2 logs konverta

# Reiniciar após atualizar arquivos
cd /var/www/konverta && pm2 restart konverta

# Atualizar código (se usar Git)
cd /var/www/konverta && git pull && pm2 restart konverta

# Ver logs de erro do Nginx
sudo tail -f /var/log/nginx/konverta_error.log

# Verificar se a porta 3001 está em uso
ss -tlnp | grep 3001
```

---

## Fluxo para configurar um cliente novo

1. Acesse `https://track.agencia110.com.br/admin?key=SUA_ADMIN_KEY`
2. **Novo cliente** → preencha nome e domínio do cliente
3. Anote o **registro TXT** gerado e peça para o cliente adicionar no DNS dele
4. Após DNS propagar → clique **Verificar DNS**
5. Aba **Plataformas** → insira Pixel ID + Access Token do Meta, ID do GA4, etc.
6. Aba **Páginas de conversão** → cole o HTML do formulário → extraia campos
7. Copie o **snippet** da aba Snippet e mande para o cliente colocar no `<head>`
8. Para ecommerces: aba **Webhooks** → gere URL para Wake / Magento / Hotmart etc.

---

## Checklist pré-lançamento por cliente

- [ ] DNS TXT verificado
- [ ] Snippet instalado no site
- [ ] Pelo menos 1 plataforma configurada (Meta ou GA4)
- [ ] Pelo menos 1 página de conversão configurada
- [ ] Testou o formulário e viu o evento chegar no Events Manager do Meta (com Test Event Code)
- [ ] Removeu o Test Event Code antes de ir para produção

---

## Troubleshooting comum

**App não inicia:**
```bash
pm2 logs konverta --lines 50
# Procure erros de conexão com banco ou variáveis ausentes
```

**Erro de conexão com PostgreSQL:**
```bash
psql -U konverta -d konverta -h localhost
# Se falhar, verifique a senha no .env
```

**Nginx retornando 502 Bad Gateway:**
```bash
# Verifica se o app está rodando
curl http://127.0.0.1:3001/health
pm2 status
```

**Certbot falhou:**
```bash
# DNS ainda não propagou — aguarde e tente novamente
dig track.agencia110.com.br A
# O IP retornado deve ser o da sua VPS
```
